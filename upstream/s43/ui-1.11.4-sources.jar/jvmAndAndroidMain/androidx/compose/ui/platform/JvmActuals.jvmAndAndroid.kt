/*
 * Copyright 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
@file:JvmName("JvmActuals_jvmKt")

package androidx.compose.ui.platform

import kotlin.DeprecationLevel.HIDDEN

internal actual typealias AtomicInt = java.util.concurrent.atomic.AtomicInteger

internal actual fun simpleIdentityToString(obj: Any, name: String?): String {
    val className =
        name
            ?: if (obj::class.java.isAnonymousClass) {
                obj::class.java.name
            } else {
                obj::class.java.simpleName
            }

    return className + "@" + String.format("%07x", System.identityHashCode(obj))
}

internal actual fun Any.nativeClass(): Any = this.javaClass

@Suppress("LESS_VISIBLE_TYPE_ACCESS_IN_INLINE_WARNING") // b/446705238
@PublishedApi
@JvmName("synchronized")
@Deprecated(
    level = HIDDEN,
    message = "not expected to be referenced directly as the old version had to be inlined",
)
internal inline fun <R> oldSynchronized(lock: SynchronizedObject, block: () -> R): R =
    kotlin.synchronized(lock, block)
