/*
 *     Dooz
 *     settings.gradle Created by Yamin Siahmargooei at 2022/3/31
 *     This file is part of Dooz.
 *     Copyright (C) 2022  Yamin Siahmargooei
 *
 *     Dooz is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     Dooz is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with Dooz.  If not, see <https://www.gnu.org/licenses/>.
 */

pluginManagement {
    repositories {
        if (settings.extra.has("usingMyket") && settings.extra.get("usingMyket").toString()
                .toBoolean()
        ) {
            maven { url = uri("https://maven.myket.ir/") }
        }
        gradlePluginPortal()
        google()
        mavenCentral()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        if (settings.extra.has("usingMyket") && settings.extra.get("usingMyket").toString()
                .toBoolean()
        ) {
            maven { url = uri("https://maven.myket.ir/") }
        }
        google()
        mavenCentral()
    }
}

rootProject.name = "Dooz"
include(":app")
include(":common")
include(":feature_game")
include(":feature_settings")
include(":feature_about")
